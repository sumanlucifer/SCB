sap.ui.define(["../controller/ErrorHandler"
], function (ErrorHandler) {
    "use strict";

    return {
        /**
         * Method for generic GET call using AJAX
         * @param {string} sPath - path for rest call 
         * @param {object} that - this object of current view
         * @author Vijay Joshi
         * @changedate 12-01-2022
         * @returns 
         */
        _GET: function (sPath, that) {
            var oAppModel = that.getModel("appView");
            oAppModel.setProperty("/busy",true);
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: sPath,
                    success: function (oResponse) {
                        oAppModel.setProperty("/busy",false);
                        resolve(oResponse);
                    },
                    error: function (oError) {               
                        oAppModel.setProperty("/busy",false);         
                        reject(oError);
                        this.showServiceError(oError,that);
                    }.bind(this)
                });
            }.bind(this));
        },        
        /**
         * Method for generic POST call using AJAX
         * @param {string} sPath - path for rest call 
         * @param {object} oData - post call data object
         * @param {object} that - this object of current view
         * @author Vijay Joshi
         * @changedate 12-01-2022
         * @returns 
         */
        _POST: function (sPath, oData, that) {
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    contentType: "application/json",
                    url: sPath,
                    data: JSON.stringify(oData),
                    success: function (oResponse) {                        
                        resolve(oResponse);                        
                    },
                    error: function (oError) {                        
                        reject(oError);
                        this.showServiceError(oError,that);                       
                    }.bind(this)
                });
            }.bind(this));
        },
        /**
         * Helper method to show service error if rest call failed
         * @param {object} oError 
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        showServiceError: function (oError,that) {
            // Show error message from the error handler
            var sErrorMsg = that.getResourceBundle().getText("errorText"),
                sDetailMsg = oError.responseText || oError.statusText;
            that.getOwnerComponent()._oErrorHandler._showServiceError(sErrorMsg, sDetailMsg);
        }
    };
});