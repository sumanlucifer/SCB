sap.ui.define([], function () {
    "use strict";

    return {        
        EMAIL_SUCCESS_MSG: "SUCCESS",
        DATE_FORMAT_KEY: "dateformat",
        DATE_RANGE_KEY: "dateRangePeriod",
        DETAIL_PAGE_ROUTE: "DetailPageRoute",
        //Common service Url
        API_CURRENT_USER: "api/userinfo/currentUser",
        API_DOC_CONTENT: "api/documents/content",
        API_SEND_EMAIL: "api/msgraph/sendEmail",
        API_EMAIL_TYPE: "api/sfsf/emailTypes",
        API_DOC_METADATA: "api/documents/metadata",
        API_DB_CONFIG: "Configurations"
        
    };
});