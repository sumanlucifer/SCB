sap.ui.define(["./RestCallUtils", "./Constants", "../model/formatter",
    "sap/ui/core/Fragment", "sap/ui/model/Sorter"
], function (RestCallUtils, Constants, formatter, Fragment, Sorter) {
    "use strict";

    return {
        formatter: formatter,
        /**
         * Event Handler for download button press
         * @param {sap.ui.base.event} oEvent 
         * @param {object} that - current this object of view
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        downloadFile: function (oEvent, bHRView, that) {
            var oAppModel = that.getModel("appView"),
                oItem = oEvent.getSource().getBindingContext("document").getObject(),
                oHRViewModel = that.getModel("hrViewModel"),
                oEmpViewModel = that.getModel("empViewModel"),
                sUrl = Constants.API_DOC_CONTENT;
                
            // SFEC-17703 -- Country Code and Legal Entity are optional Take payload from filter -- fix by Nibedita Sahoo
                //iDateValue = parseFloat(oItem.DocRecDate),
                //oDocDate = new Date(iDateValue),
                //sEpochDocDate = this.formatter.formateDatetoEPOCHDate(oDocDate);
            var oPayload = {
                    "DocId": oItem.DocId,
                    "isHRView": bHRView.toString()
            };
            if(bHRView){
                //Payload from HR filters
                var sDocumentType = oHRViewModel.getProperty("/documentType"),
				    sBankId = oHRViewModel.getProperty("/bankIdValue"),
				    oLegalEntity = oHRViewModel.getProperty("/legalEntities"),
				    oCountry = oHRViewModel.getProperty("/countries"),
				    oStartDate = oHRViewModel.getProperty("/startDate"),
				    oEndDate = oHRViewModel.getProperty("/endDate");
			    // Backend api required date to be formatted with EPOCH date                
			    var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
			 	    epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);
                oPayload.startDate = epochStartDate;
                oPayload.endDate = epochEndDate;
                oPayload.documentType = sDocumentType;
                oPayload.bankId = sBankId;
                if(oCountry.length){
                    oPayload.country = oCountry[0];
                }
                if(oLegalEntity.length){
                    oPayload.legalEntity = oLegalEntity[0];
                }
            }else{
                //Payload from My Document Filter
				var sDocumentType = oEmpViewModel.getProperty("/documentType"),
				    oStartDate = oEmpViewModel.getProperty("/startDate"),
				    oEndDate = oEmpViewModel.getProperty("/endDate");
			 	// Backend api required date to be formatted with EPOCH date                
			 	var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
			 		epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);
				oPayload.startDate = epochStartDate;
				oPayload.endDate = epochEndDate;
				oPayload.documentType = sDocumentType;
            }
            
            /*var oPayload = {
                "startDate": sEpochDocDate,
                "endDate": sEpochDocDate,
                "documentType": oItem.DocType,
                "DocId": oItem.DocId,
                "isHRView": bHRView.toString()
            };
            if (bHRView) {
                oPayload.bankId = oItem.BankID;
                oPayload.country = oItem.CntryCode;
                oPayload.legalEntity = oItem.LegalEntityName;
            }*/
            /*var oPayload = {
				"startDate": epochStartDate,
				"endDate": epochEndDate,
				"documentType": sDocumentType,
				"DocId": oItem.DocId,
				"isHRView": bHRView.toString()
			};
			if (bHRView) {
                oPayload.bankId = sBankId;
				if(oCountry.length){
					oPayload.country = oCountry[0];
				}
				if(oLegalEntity.length){
					oPayload.legalEntity = oLegalEntity[0];
				}
            }*/
            //SFEC - 17703 - end   
            oAppModel.setProperty("/busy", true);
            RestCallUtils._POST(sUrl, oPayload, that).then(function (oRes) {
                var sFileName = oRes.fileName,
                    sFileContent = oRes.fileContent,
                    sContentType = oRes.fileMimeType;
                this.saveFile(sFileName, sContentType, sFileContent);
                oAppModel.setProperty("/busy", false);
            }.bind(this)).
                catch(function (oError) {
                    oAppModel.setProperty("/busy", false);
                }.bind(this));
        },
        /**
         * Helper method to save file to default folder set by browser
         * @param {string} sFileName 
         * @param {string} sContentType
         * @param {string} sFileContent - base64 encoded string
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        saveFile: function (sFileName, sContentType, sFileContent) {
            if (sFileContent) {
                var oAttachment = document.createElement('a');
                oAttachment.href = "data:" + sContentType + ";base64," + sFileContent;
                oAttachment.download = sFileName;
                document.body.appendChild(oAttachment);
                oAttachment.click();
                document.body.removeChild(oAttachment);                
            }
        },
        /**
         * Helper method to validate the mandatory filter
         * it will return true false if required filter are provided value or not
         * @param {sap.ui.base.event} oEvent 
         * @param {object} that - current this object of view
         * @author Vijay Joshi
         * @changedate 12-01-2022
         * @returns 
         */
        validateMandatoryFilter: function (oEvent, that) {
            var aFilterGroupItems = oEvent.getSource().getFilterGroupItems(),
                oRM = that.getResourceBundle(),
                oFilterGroupItem, oControl, sValue, bMandatory, bFilterValid = true;
            for (var iItem = 0; iItem < aFilterGroupItems.length; iItem++) {
                oFilterGroupItem = aFilterGroupItems[iItem];
                bMandatory = oFilterGroupItem.getProperty("mandatory");
                oControl = oFilterGroupItem.getControl();
                if (oControl instanceof sap.m.Select) {
                    sValue = oControl.getSelectedKey();
                } else {
                    sValue = oControl.getValue();
                }
                if (bMandatory && sValue.trim() === "") {
                    oControl.setValueState(sap.ui.core.ValueState.Error);
                    oControl.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oFilterGroupItem.getLabel()]));
                    bFilterValid = false;
                }
                else if (oControl.getValueState() === sap.ui.core.ValueState.Error) {
                    bFilterValid = false;
                }
                else {
                    oControl.setValueState(sap.ui.core.ValueState.None);
                    oControl.setValueStateText("");
                }
            }
            return bFilterValid;
        },
        /**
         * Event handler for date range filter selection change
         * @param {sap.ui.base.event} oEvent - event object
         * @param {object} that - current this object of view
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        onDateRangeChange: function (oEvent, that) {
            var oSource = oEvent.getSource(),
                oAppModel = that.getModel("appView"),
                iMaxDateRange = oAppModel.getProperty("/dateRangeMaxValue"),
                oRM = that.getResourceBundle(),
                oStartDate = oEvent.getSource().getDateValue(),
                oEndDate = oEvent.getSource().getSecondDateValue();
            if (oSource.getValue()) {
                var diffTime = Math.abs(oEndDate - oStartDate);
                // diff logic to get year and month from date and then do calculation
                var diffMonth = Math.round(diffTime / (2e3 * 3600 * 365.25));
                if (diffMonth > iMaxDateRange) {
                    oSource.setValueState(sap.ui.core.ValueState.Error);
                    oSource.setValueStateText(oRM.getText("filterbar.dateRangeExceedMsg", [iMaxDateRange]));
                    oSource.setShowValueStateMessage(true);
                } else {
                    oSource.setValueState(sap.ui.core.ValueState.None);
                    oSource.setValueStateText("");
                    oSource.setShowValueStateMessage(false);
                }
            }           
        },
        /**
         * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the button press event
         * @public
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        onOpenViewSettings: function (oEvent, that) {
            // load asynchronous XML fragment
            this.context = that;
            if (!this.viewSettingsDialog) {
                Fragment.load({
                    id: that.getView().getId(),
                    name: "org.sap.cap.scb.document.retreival.view.fragments.ViewSettingsDialog",
                    controller: this
                }).then(function (oDialog) {
                    // connect dialog to the root view of this component (models, lifecycle)
                    that.getView().addDependent(oDialog);
                    oDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    oDialog.open();
                });
            } else {
                this.viewSettingsDialog.open();
            }
        },

        /**
         * Event handler called when ViewSettingsDialog has been confirmed, i.e.
         * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
         * are applied to the master list, which can also mean that they
         * are removed from the master list, in case they are
         * removed in the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the confirm event
         * @public
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        onConfirmViewSettingsDialog: function (oEvent) {
            this._applySortGroup(oEvent);
        },

        /**
         * Apply the chosen sorter and grouper to the master list
         * @param {sap.ui.base.Event} oEvent the confirm event
         * @private
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        _applySortGroup: function (oEvent) {
            var mParams = oEvent.getParameters(),
                sPath,
                bDescending,
                aSorters = [];
            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            aSorters.push(new Sorter(sPath, bDescending));
            this.context._oList.getBinding("items").sort(aSorters);
        },
        /**
         * Helper method to get default configuration for Date range filter
         * @param {object } that - current view context
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
        getDefaultConfiguration: function (that) {
            var oAppModel = that.getModel("appView"),
                sServiceUrl = that.getModel().sServiceUrl,
                sUrl = sServiceUrl + Constants.API_DB_CONFIG;
            oAppModel.setProperty("/busy", true);
            RestCallUtils._GET(sUrl, that).then(function (oRes) {
                var oData = oRes.value;
                oAppModel.setProperty("/Configurations", oData);
                if (oData && oData.length && oData.length > 0) {
                    var sDateFormat = Constants.DEFAULT_DATE_FORMAT,
                        aDateFormat = oData.filter(config => config.categoryKey === Constants.DATE_FORMAT_KEY),
                        iMaxDateRange = Constants.ALLOWED_DATE_RANGE,
                        aMaxDateRange = oData.filter(config => config.categoryKey === Constants.DATE_RANGE_KEY);
                    if (aDateFormat && aDateFormat.length && aDateFormat.length > 0) {
                        sDateFormat = aDateFormat[0].startValue;
                    }
                    if (aMaxDateRange && aMaxDateRange.length && aMaxDateRange.length > 0) {
                        iMaxDateRange = aMaxDateRange[0].startValue;
                    }
                    oAppModel.setProperty("/dateRangeMaxValue", iMaxDateRange);
                    oAppModel.setProperty("/dateFormat", sDateFormat);
                }
                oAppModel.setProperty("/busy", false);
            }).
                catch(function (oError) {
                    oAppModel.setProperty("/busy", false);
                });
        },
        /**
		 * Helper method to convert base64 string into Blob		
		 * @param {string} b64Data 
		 * @param {string} contentType 
		 * @param {integer} sliceSize 
         * @author Vijay Joshi
         * @changedate 12-01-2022
		 * @returns 
		 */
		b64toBlob: function (b64Data, contentType, sliceSize) {
			contentType = contentType || '';
			sliceSize = sliceSize || 512;
			var byteCharacters = window.atob(b64Data);
			var byteArrays = [];
			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);
				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
				}
				var byteArray = new Uint8Array(byteNumbers);
				byteArrays.push(byteArray);
			}
			var blob = new Blob(byteArrays, {
				type: contentType
			});
			return blob;
		},
        /**
         * Helper method to get Current user context from java API
         * This API call will return the role related data of current user
         * As well as associated country and legal entity if user is HR admin
         * Basic Information regarding the user as well
         * @author Vijay Joshi
         * @changedate 12-01-2022
         */
         getUserInfo: function (that) {
            return new Promise(function (resolve, reject) {
                var oAppModel = that.getModel("appView"),
                    oUserModel = that.getModel("userModel");
                var sUrl = Constants.API_CURRENT_USER;
                oAppModel.setProperty("/busy", true);
                RestCallUtils._GET(sUrl, that).then(function (oRes) {
                    oUserModel.setProperty("/IsHR", oRes.hr);
                    oUserModel.setProperty("/IsEmp", oRes.employee);
                    oUserModel.setProperty("/BankId", oRes.bankId);
                    if (oRes.countries) {
                        oUserModel.setProperty("/Countries", oRes.countries);
                    }
                    if (oRes.legalEntities) {
                        oUserModel.setProperty("/LegalEntities", oRes.legalEntities);
                    }
                    oUserModel.refresh(true);
                    if (oRes.hr || oRes.employee) {                        
                        oAppModel.setProperty("/busy", false);   
                        resolve("success");                    
                    }else{
                        that.getRouter().navTo("unAuthorized", false);
                        reject("unauthorized");
                    }                    
                }.bind(this)).
                    catch(function (oError) {
                        oAppModel.setProperty("/busy", false);
                        oUserModel.setProperty("/IsHR", false);
                        oUserModel.setProperty("/IsEmp", false);
                        that.getRouter().navTo("unAuthorized");
                        reject(oError);
                    }.bind(this));
            });
        }
    };
});