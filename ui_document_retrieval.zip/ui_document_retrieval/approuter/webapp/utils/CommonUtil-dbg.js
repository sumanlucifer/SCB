sap.ui.define(["../model/formatter",
    "../utils/RestCallUtils",
    "../utils/AppUtil",
    "../utils/Constants",
    "sap/ui/Device",
], function (formatter, RestCallUtils, AppUtil, Constants, Device) {
    "use strict";

    return {
        formatter: formatter,
        /**
         * Helper method to set viewmodel data
         * @param {string} sTitle 
         * @param {boolean} bHR 
         * @param {boolean} bEmp 
         * @author Vijay Joshi
         * @changedate 20-11-2021
         */
        _setViewData: function (sTitle, bHR, bEmp, oViewModel, that) {
            var oAppModel = that.getModel("appView");
            if (oAppModel.getProperty("/prevRoute") !== Constants.DETAIL_PAGE_ROUTE) {
                this.onPressClear(null, oViewModel, that);
            }
            //Set the layout property of the FCL control to 'OneColumn'
            oAppModel.setProperty("/prevRoute", "");
            oAppModel.setProperty("/layout", "OneColumn");
            oAppModel.setProperty("/appTitle", that.getResourceBundle().getText(sTitle));
            that._oList.removeSelections(true);
            oViewModel.setProperty("/isEmp", bEmp);
            oViewModel.setProperty("/isHR", bHR);
        },
        /**
         * Event handler for the list selection event
         * @param {sap.ui.base.Event} oEvent the list selectionChange event
         * @public
         */
        selectionChange: function (oEvent, that, bHR) {
            var oList = oEvent.getSource(),
                bSelected = oEvent.getParameter("selected");
            // skip navigation when deselecting an item in multi selection mode
            if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
                // get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
                this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource(), that, bHR);
            }
        },
        /**
         * Shows the selected item on the detail page
         * On phones a additional history entry is created
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showDetail: function (oItem, that, bHR) {
            var bReplace = !Device.system.phone;
            // set the layout property of FCL control to show two columns
            that.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
            // Get document list from json model and then get the index of selected
            // item, which needs to be passed in details page
            var oDocModel = that.getModel("document"),
                aDocuments = oDocModel.getProperty("/items"),
                oItemObject = oItem.getBindingContext("document").getObject(),
                iItemIndex = aDocuments.indexOf(oItemObject);
            if (bHR) {
                that.getRouter().navTo("EmployeeDocumentObject", {
                    objectId: iItemIndex
                }, bReplace);
            } else {
                that.getRouter().navTo("object", {
                    objectId: iItemIndex
                }, bReplace);
            }
        },
        /**
         * Event handler for document type change event
         * @param {sap.ui.base.event} oEvent 
         */
        onDocumentTypeChange: function (oEvent, that) {
            var oSource = oEvent.getSource(),
                oRM = that.getResourceBundle(),
                sValue = oSource.getSelectedKey();
            if (sValue && sValue.trim() === "") {
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oRM.getText("filterbar.documentType")]));
            } else {
                oSource.setValueState(sap.ui.core.ValueState.None);
                oSource.setValueStateText("");
            }
        },
        /**
         * Helper method to get document list
         * @param {string} sUrl 
         * @param {object} oPayload 
         * @param {object} that 
         */
        getDocumentList: function (sUrl, oPayload, that) {
            var oAppModel = that.getModel("appView");
            oAppModel.setProperty("/busy", true);
            RestCallUtils._POST(sUrl, oPayload, that).then(function (oRes) {
                var oDocumentModel = that.getModel("document"), sTitle;
                oDocumentModel.setProperty("/items", oRes.documents[0].Result[0].Result);
                sTitle = that.getResourceBundle().getText("documentlist.titleCount", [oRes.totalRecords]);
                oDocumentModel.setProperty("/title", sTitle);
                oDocumentModel.refresh(true);
                oAppModel.setProperty("/showSorting", true);
                oAppModel.setProperty("/busy", false);
            }.bind(this)).
                catch(function (oError) {
                    oAppModel.setProperty("/busy", false);
                }.bind(this));
        },
        /**
         * Event handler for clear button press event
         * @param {sap.ui.base.event} oEvent 
         */
        onPressClear: function (oEvent, oViewModel, that) {
            var oAppModel = that.getModel("appView"),
                oDocModel = that.getModel("document"),
                oControl, oFilterItem,
                aFilterItems;
            if (oViewModel.getProperty("/IsHR")) {
                aFilterItems = that.byId("scbHRViewFilter").getFilterGroupItems();
            } else {
                aFilterItems = that.byId("scbEmpViewFilter").getFilterGroupItems();
            }
            oAppModel.setProperty("/busy", true);
            for (var iItem = 0; iItem < aFilterItems.length; iItem++) {
                oFilterItem = aFilterItems[iItem];
                oControl = oFilterItem.getControl();
                if (oControl instanceof sap.m.Select) {
                    oControl.setSelectedKey("");
                }
                if (oControl instanceof sap.m.ComboBox) {
                    oControl.setValue(null);
                    oControl.clearSelection();
                }
                else {
                    oControl.setValue(null);
                }
            }
            // clear list on clearing of filter
            oDocModel.setProperty("/items", []);
            oDocModel.setProperty("/title", that.getResourceBundle().getText("documentlist.titleCount", [0]));

            if (oViewModel.getProperty("/IsHR")) {
                var oCountryComboCombo = that.byId("scbCountryCombo"),
                    oLegalEntityCombo = that.byId("scbLegalEntityCombo");
                oCountryComboCombo.getBinding("items").filter([]);
                oLegalEntityCombo.getBinding("items").filter([]);
                oViewModel.setProperty("/bankIdValueState", sap.ui.core.ValueState.None);
                oViewModel.setProperty("/bankIdValueStateText", "");
            }
            oViewModel.setProperty("/showWarningMsg", false);
            // clear the value state and value state text
            oViewModel.setProperty("/docTypeValueState", sap.ui.core.ValueState.None);
            oViewModel.setProperty("/dateRangeValueState", sap.ui.core.ValueState.None);
            oViewModel.setProperty("/docTypeValueStateText", "");
            oViewModel.setProperty("/dateRangeValueStateText", "");
            oAppModel.setProperty("/showSorting", false);
            oAppModel.setProperty("/busy", false);
        }
    };
});