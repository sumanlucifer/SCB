sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "../model/formatter",
    "../utils/RestCallUtils",
    "../utils/AppUtil",
    "../utils/Constants",
    "../utils/CommonUtil"
], function (BaseController, JSONModel, Device, formatter, RestCallUtils, AppUtil, Constants, CommonUtil) {
    "use strict";

    return BaseController.extend("org.sap.cap.scb.document.retreival.controller.MyDocuments", {
        // default formatter for xml view
        formatter: formatter,
        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */
        /**
         * Called when the controller is instantiated. 
         * It sets up the event handling and other lifecycle tasks.
         * @author Vijay Joshi
         * @changedate 20-10-2021
         * @public
         */
        onInit: function () {
            // Control state model
            var oList = this.byId("scbDocumentList");
               /* oViewModel = new JSONModel({
                    delay: 0,
                    dateRangeMaxValue: 0,
                    dateFormatter: "",
                    showWarningMsg: false,
                    IsHR: false
                });*/

            this._oList = oList;
            // keeps the filter and search state
            this._oListFilterState = {
                aFilter: [],
                aSearch: []
            };

            //this.setModel(oViewModel, "empViewModel");
            this.getView().addEventDelegate({
                onBeforeFirstShow: function () {
                    this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
                }.bind(this)
            });

            this.getRouter().getRoute("MyDocuments").attachPatternMatched(this._onPatternMatched, this);
            this.getRouter().attachBypassed(this.onBypassed, this);
        },

        /**
         * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the button press event
         * @public
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onOpenViewSettings: function (oEvent) {
            AppUtil.onOpenViewSettings(oEvent, this);
        },

        /**
         * Event handler for the list selection event
         * @param {sap.ui.base.Event} oEvent the list selectionChange event
         * @public
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onSelectionChange: function (oEvent) {
            CommonUtil.selectionChange(oEvent, this,false);
        },

        /**
         * Event handler for the bypassed event, which is fired when no routing pattern matched.
         * If there was an object selected in the master list, that selection is removed.
         * @public
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onBypassed: function () {
            this._oList.removeSelections(true);
        },
        /**
         * Event handler for router pattern matched event
         * @param {sap.ui.base.Event} oEvent
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        _onPatternMatched: function (oEvent) {
            var oViewModel = this.getModel("empViewModel"),
                oUserModel = this.getModel("userModel");
            if (oUserModel.getProperty("/IsEmp")) {
                CommonUtil._setViewData("shell.empViewTitle", false, true, oViewModel, this);
            } else {
                AppUtil.getUserInfo(this).then(function (oRes) {
                    CommonUtil._setViewData("shell.empViewTitle", false, true, oViewModel, this);
                }.bind(this))
            }
        },
        /**
         * Event handler for filter Go button press event
         * @param {sap.ui.base.event} oEvent - event object
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        searchDocuments: function (oEvent) {
            var oViewModel = this.getModel("empViewModel"),
                bFilterValid = this.validateMandatoryFilter(oEvent);
            if (bFilterValid) {
                oViewModel.setProperty("/showWarningMsg", false);
                var sDocumentType = oViewModel.getProperty("/documentType"),
                    oStartDate = oViewModel.getProperty("/startDate"),
                    oEndDate = oViewModel.getProperty("/endDate");
                // Backend api required date to be formatted with EPOCH date                
                var epochStartDate = this.formatter.formateDatetoEPOCHDate(oStartDate),
                    epochEndDate = this.formatter.formateDatetoEPOCHDate(oEndDate);
                var sUrl = Constants.API_DOC_METADATA;
                var oPayload = {
                    "startDate": epochStartDate,
                    "endDate": epochEndDate,
                    "documentType": sDocumentType,
                    "isHRView": "false"
                };
                CommonUtil.getDocumentList(sUrl, oPayload, this);
            } else {
                oViewModel.setProperty("/showWarningMsg", true);
            }
        },
        /**
         * Event handler for date range filter selection change
         * @param {sap.ui.base.event} oEvent - event object
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onDateRangeChange: function (oEvent) {
            AppUtil.onDateRangeChange(oEvent, this);
        },
        /**
         * Helper method to validate the mandatory filter
         * it will return true false if required filter are provided value or not
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 20-10-2021
         * @returns 
         */
        validateMandatoryFilter: function (oEvent) {
            return AppUtil.validateMandatoryFilter(oEvent, this);
        },
        /**
         * Event Handler for download button press
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onPressDownload: function (oEvent) {
            AppUtil.downloadFile(oEvent,false, this);
        },
        /**
         * Event handler for document type change event
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 20-10-2021
         */
        onDocumentTypeChange: function (oEvent) {
            CommonUtil.onDocumentTypeChange(oEvent, this);
        },
        /**
        * Event handler for clear button press event
        * @param {sap.ui.base.event} oEvent 
        * @author Vijay Joshi
        * @changedate 20-10-2021
        */
        onPressClear: function (oEvent) {
            var oViewModel = this.getModel("empViewModel");
            CommonUtil.onPressClear(oEvent, oViewModel, this);
        }
    });

});