sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"../utils/RestCallUtils",
	"../utils/Constants",
	"../utils/AppUtil",
	"sap/m/MessageBox",
	'sap/ui/core/Fragment'
], function (BaseController, JSONModel, formatter, RestCallUtils, Constants, AppUtil, MessageBox, Fragment) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.retreival.controller.Detail", {
		// local xml formatter
		formatter: formatter,
		/**
		 * @author Vijay Joshi
		 * @changedate 20-10-2021
		 */
		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				fileContent: "",
				fileName: "",
				showEmail: false,
				IsHRView: false,
				EmailTypes: []
			});
			this.getRouter().getRoute("object").attachPatternMatched(this._onEmpViewPatternMatch, this);
			this.getRouter().getRoute("EmployeeDocumentObject").attachPatternMatched(this._onHRViewPatternMatch, this);
			this.setModel(oViewModel, "detailView");
			this._PDFViewer = this.byId("scbPDFViewer");
		},
		/**
		 * Helper method to set busy
		 * @author Vijay Joshi
		 * @changedate 02-04-2022
		 * @param {boolean} bBusy 
		 */
		_setBusy: function(bBusy){
			this.getModel("detailView").setProperty("/busy",bBusy);
		},
		/**
		 * Event handler for Employee view route match event
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 * @param {sap.ui.base.event} oEvent 
		 */
		_onEmpViewPatternMatch: function (oEvent) {
			var oUserModel = this.getModel("userModel");            
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/showEmail", true);
			oViewModel.setProperty("/IsHRView", false);
			this.getEmailSendingOptions();
			this._onObjectMatched(oEvent);
		},
		/**
		 * Event handler for HR view route match event
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 * @param {sap.ui.base.event} oEvent 
		 */
		_onHRViewPatternMatch: function (oEvent) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/showEmail", false);
			oViewModel.setProperty("/IsHRView", true);
			this._onObjectMatched(oEvent);
		},
		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		_onObjectMatched: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.documentId = sObjectId;
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			// we are getting index of the selected item from master page,
			// using the index binding the json model path to detail page	
			this._bindView("document>/items/" + sObjectId);
		},
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		_bindView: function (sObjectPath) {
			var oDocModel = this.getModel("document"),
				aDocuments = oDocModel.getProperty("/items");
			if (aDocuments && aDocuments && aDocuments.length > 0) {
				this.getView().bindElement(sObjectPath);
				var oItem = oDocModel.getProperty("/items/" + this.documentId);
				this.getDocumentContent(oItem);
			} else {
				// if refresh has happend on the page then we will not get document list
				// in document model so in that case do a navigation to master page
				// to enable user to get the data
				this.getRouter().navTo("MyDocuments");
			}
		},
		/**
		 * Helper method to get document content and show it on pdf viewer
		 * @param {object} oItem - item object
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		getDocumentContent: function (oFileData) {
			var oAppModel = this.getModel("appView"),
				oViewModel = this.getModel("detailView"),
				oHRViewModel = this.getModel("hrViewModel"),
				oEmpViewModel = this.getModel("empViewModel"),
				sUrl = Constants.API_DOC_CONTENT;
			var oFileData = this.getView().getBindingContext("document").getObject();			
			var bHRView = oViewModel.getProperty("/IsHRView");
			//SFEC-17703 -- Country Code and Legal Entity are optional - Payload data from filter-- fix by Nibedita Sahoo
				//iDateValue = parseFloat(oFileData.DocRecDate),
				//oDocDate = new Date(iDateValue),
				//sEpochDocDate = this.formatter.formateDatetoEPOCHDate(oDocDate);
			var oPayload = {
				"DocId": oFileData.DocId,
				"isHRView": bHRView.toString()
			};
			if(bHRView){
				//Payload from HR filters
				var sDocumentType = oHRViewModel.getProperty("/documentType"),
				sBankId = oHRViewModel.getProperty("/bankIdValue"),
				oLegalEntity = oHRViewModel.getProperty("/legalEntities"),
				oCountry = oHRViewModel.getProperty("/countries"),
				oStartDate = oHRViewModel.getProperty("/startDate"),
				oEndDate = oHRViewModel.getProperty("/endDate");
			 	// Backend api required date to be formatted with EPOCH date                
			 	var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
			 		epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);
				oPayload.startDate = epochStartDate;
				oPayload.endDate = epochEndDate;
				oPayload.documentType = sDocumentType;
				oPayload.bankId = sBankId;
				if(oCountry.length){
					oPayload.country = oCountry[0];
				}
				if(oLegalEntity.length){
					oPayload.legalEntity = oLegalEntity[0];
				}
			}else{
				//Payload from My Document Filter
				var sDocumentType = oEmpViewModel.getProperty("/documentType"),
				oStartDate = oEmpViewModel.getProperty("/startDate"),
				oEndDate = oEmpViewModel.getProperty("/endDate");
			 	// Backend api required date to be formatted with EPOCH date                
			 	var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
			 		epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);
				oPayload.startDate = epochStartDate;
				oPayload.endDate = epochEndDate;
				oPayload.documentType = sDocumentType;
			}
			
			/*var oPayload = {
				"startDate": sEpochDocDate,
				"endDate": sEpochDocDate,
				"documentType": oFileData.DocType,
				"DocId": oFileData.DocId,
				"isHRView": bHRView.toString()
			};
			if (bHRView) {
				oPayload.bankId = oFileData.BankID;
                oPayload.country = oFileData.CntryCode;
                oPayload.legalEntity = oFileData.LegalEntityName;
			}*/
			//End of defect fix for SFEC-17703
			this._setBusy(true);
			RestCallUtils._POST(sUrl, oPayload, this).then(function (oRes) {
				var contentType = oRes.fileMimeType;
				var b64Data = oRes.fileContent;
				var blob = AppUtil.b64toBlob(b64Data, contentType);
				//Pdf viewer is not able to display base64 string so
				//we are converting base64 sting to blob url and binding that to pdf viewer			
				var blobUrl = URL.createObjectURL(blob);
				jQuery.sap.addUrlWhitelist("blob");
				oViewModel.setProperty("/fileUrl", blobUrl);
				oViewModel.setProperty("/fileName", oRes.fileName);
				oViewModel.setProperty("/fileContent", oRes.fileContent);
				oViewModel.setProperty("/fileContentType", oRes.fileMimeType);
				oViewModel.refresh(true);
				this._setBusy(false);
			}.bind(this)).
				catch(function (oError) {
					this._setBusy(false);
				}.bind(this));
		},
		/**
		 * Helper method to Set the full screen mode to false and navigate to master page
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		onCloseDetailPress: function () {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			var sCurrentHash = this.getRouter().getHashChanger().getHash();
			if (sCurrentHash.indexOf("EmployeeDocuments") >= 0) {
				this.getRouter().navTo("EmployeeDocuments");
			} else {
				this.getRouter().navTo("MyDocuments");
			}
			this.getModel("appView").setProperty("/prevRoute", Constants.DETAIL_PAGE_ROUTE);
		},
		/**
		 * Toggle between full and non full screen mode.
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},
		/**
		 * Event Handler for download button press
		 * @param {sap.ui.base.event} oEvent 
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		onPressDownload: function (oEvent) {
			var oViewModel = this.getModel("detailView"),
				sFileName = oViewModel.getProperty("/fileName"),
				sContentType = oViewModel.getProperty("/fileContentType"),
				sFileContent = oViewModel.getProperty("/fileContent");
			AppUtil.saveFile(sFileName, sContentType, sFileContent);
		},
		/**
		 * Event handler for action Email button press event
		 * This method will use to open action items
		 * @param {sap.ui.base.event} oEvent 
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		onPressEmail: function (oEvent) {
			var oButton = oEvent.getSource();
			this.byId("scbActionSheet").openBy(oButton);
		},
		/**
		 * Helper method for sending email
		 * @param {sap.ui.base.event} oEvent 
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		sendEmail: function (oEvent) {
			var oButton = oEvent.getSource().getBindingContext("detailView").getObject(),
				sOption = oButton.optionId;
			var oFileData = this.getView().getBindingContext("document").getObject();
			//SFEC-17703 - Payload data from filter-- fix by Nibedita Sahoo
			/*var iDateValue = parseFloat(oFileData.DocRecDate),
				oDocDate = new Date(iDateValue),
				sEpochDocDate = this.formatter.formateDatetoEPOCHDate(oDocDate)*/
			var oEmpViewModel = this.getModel("empViewModel");
			var sDocumentType = oEmpViewModel.getProperty("/documentType"),
				oStartDate = oEmpViewModel.getProperty("/startDate"),
				oEndDate = oEmpViewModel.getProperty("/endDate");
			 	// Backend api required date to be formatted with EPOCH date                
			 	var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
			 		epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);	
			var sConfirmEmailSent = this.getResourceBundle().getText("detail.emailConfirmMsg");
			MessageBox.confirm(sConfirmEmailSent, {
				styleClass: this.getOwnerComponent().getContentDensityClass(),
				onClose: function (sAction) {
					if (sAction === MessageBox.Action.OK) {
						var oAppModel = this.getModel("appView");
						var oPayload = {
							"startDate": epochStartDate,
							"endDate": epochEndDate,
							"documentType": sDocumentType,
							"DocId": oFileData.DocId,
							"emailIdType": sOption,
							"isHRView": false
						};
						
						oAppModel.setProperty("/busy", true);
						var sUrl = Constants.API_SEND_EMAIL;
						RestCallUtils._POST(sUrl, oPayload, this).then(function (oRes) {
							oAppModel.setProperty("/busy", false);
							if (oRes.message === Constants.EMAIL_SUCCESS_MSG) {
								var sMsg = this.getResourceBundle().getText("detail.emailSentMsg");
								sap.m.MessageToast.show(sMsg);
							}
						}.bind(this)).
							catch(function (oError) {
								oAppModel.setProperty("/busy", false);
							}.bind(this));
					}
				}.bind(this)
			});
		},
		/**
		 * Helper method to get Email sending option from backend
		 * If user has only Business email then that option will be enable
		 * If user does not have personal email configured then that option will be disable
		 * @author Vijay Joshi
		 * @changedate 20-12-2021
		 */
		getEmailSendingOptions: function () {
			var oAppModel = this.getModel("appView"),
				oViewModel = this.getModel("detailView");
			oAppModel.setProperty("/busy", true);
			var sUrl = Constants.API_EMAIL_TYPE;
			RestCallUtils._GET(sUrl, this).then(function (oRes) {
				oAppModel.setProperty("/busy", false);
				oViewModel.setProperty("/EmailTypes", oRes);
			}.bind(this)).
				catch(function (oError) {
					oAppModel.setProperty("/busy", false);
				}.bind(this));
		}
	});

});