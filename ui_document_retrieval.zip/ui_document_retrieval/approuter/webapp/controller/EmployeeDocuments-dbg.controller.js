sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/Device",
    "../model/formatter",
    "../utils/RestCallUtils",
    "../utils/AppUtil",
    "../utils/Constants",
    "../utils/CommonUtil"
], function (BaseController, JSONModel, Filter, FilterOperator, Device, formatter, RestCallUtils, AppUtil, Constants, CommonUtil) {
    "use strict";

    return BaseController.extend("org.sap.cap.scb.document.retreival.controller.EmployeeDocuments", {
        // default formatter for xml view
        formatter: formatter,
        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the controller is instantiated. 
         * It sets up the event handling and other lifecycle tasks.
         * @public
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onInit: function () {
            // Control state model
            var oList = this.byId("scbDocumentList");
            this._oList = oList;
            // keeps the filter and search state
            this._oListFilterState = {
                aFilter: [],
                aSearch: []
            };
            
            this.getView().addEventDelegate({
                onBeforeFirstShow: function () {
                    this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
                }.bind(this)
            });

            this.getRouter().getRoute("EmployeeDocuments").attachPatternMatched(this._onPatternMatched, this);
            this.getRouter().attachBypassed(this.onBypassed, this);
        },

        /**
         * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the button press event
         * @public
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onOpenViewSettings: function (oEvent) {
            AppUtil.onOpenViewSettings(oEvent, this);
        },

        /**
         * Event handler for the list selection event
         * @param {sap.ui.base.Event} oEvent the list selectionChange event
         * @public
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onSelectionChange: function (oEvent) {
            CommonUtil.selectionChange(oEvent, this,true);
        },

        /**
         * Event handler for the bypassed event, which is fired when no routing pattern matched.
         * If there was an object selected in the master list, that selection is removed.
         * @public
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onBypassed: function () {
            this._oList.removeSelections(true);
        },

        /**
         * Event handler for router pattern matched event
         * @param {sap.ui.base.Event} oEvent
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        _onPatternMatched: function (oEvent) {
            var oViewModel = this.getModel("hrViewModel"),
                oUserModel = this.getModel("userModel");
            //SFEC- 17703
            oViewModel.setProperty("/IsHR",true);
            //End of defect fix for SFEC-17703
            if (oUserModel.getProperty("/IsHR")) {
                CommonUtil._setViewData("shell.hrViewTitle", true, false, oViewModel, this);
            } else {
                AppUtil.getUserInfo(this).then(function (oRes) {
                    CommonUtil._setViewData("shell.hrViewTitle", true, false, oViewModel, this);
                }.bind(this))
            }
        },
        /**
         * Event handler for filter Go button press event
         * @param {sap.ui.base.event} oEvent - event object
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        searchDocuments: function (oEvent) {
            var oViewModel = this.getModel("hrViewModel"),
                bFilterValid = this.validateMandatoryFilter(oEvent);
            if (bFilterValid) {
                oViewModel.setProperty("/showWarningMsg", false);
                var sDocumentType = oViewModel.getProperty("/documentType"),
                    sBankId = oViewModel.getProperty("/bankIdValue"),
                    sLegalEntity = oViewModel.getProperty("/legalEntityValue"),
                    sCountry = oViewModel.getProperty("/countryValue"),
                    oStartDate = oViewModel.getProperty("/startDate"),
                    oEndDate = oViewModel.getProperty("/endDate");
                // Backend api required date to be formatted with EPOCH date                
                var epochStartDate = formatter.formateDatetoEPOCHDate(oStartDate),
                    epochEndDate = formatter.formateDatetoEPOCHDate(oEndDate);

                var sUrl = Constants.API_DOC_METADATA;
                var oPayload = {
                    "bankId": sBankId,
                    "startDate": epochStartDate,
                    "endDate": epochEndDate,
                    "documentType": sDocumentType,
                    "country": sCountry,
                    "legalEntity": sLegalEntity,
                    "isHRView": "true"
                };
                CommonUtil.getDocumentList(sUrl, oPayload, this);
            } else {
                oViewModel.setProperty("/showWarningMsg", true);
            }
        },
        /**
         * Event handler for date range filter selection change
         * @param {sap.ui.base.event} oEvent - event object
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onDateRangeChange: function (oEvent) {
            AppUtil.onDateRangeChange(oEvent, this);
        },
        /**
         * Helper method to validate the mandatory filter
         * it will return true false if required filter are provided value or not
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         * @returns 
         */
        validateMandatoryFilter: function (oEvent) {
            return AppUtil.validateMandatoryFilter(oEvent, this);
        },
        /**
         * Event Handler for download button press
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onPressDownload: function (oEvent) {
            AppUtil.downloadFile(oEvent,true, this);
        },
        /**
         * Event handler for document type change event
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onDocumentTypeChange: function (oEvent) {
            CommonUtil.onDocumentTypeChange(oEvent, this);
        },
        /**
         * Event handler for bank id live change event
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onInputLiveChange: function (oEvent) {
            var oRM = this.getResourceBundle(),
                oSource = oEvent.getSource(),
                sValue = oSource.getValue();
            if (sValue.trim() == "") {
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oRM.getText("filterbar.bankId")]));
            }
            else if (!sValue.trim().match("^[0-9]*$")) {
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.bankIdValidationMsg"));
            }
            else {
                oSource.setValueState(sap.ui.core.ValueState.None);
                oSource.setValueStateText("");
            }
        },
        /**
         * Event handler for country filter change event
         * based on the selected country, legal entity data will be filtered
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onChangeCountry: function (oEvent) {
            var oItem = oEvent.getSource().getSelectedItem(),
                oLegalEntityCombo = this.byId("scbLegalEntityCombo");
            if (oItem) {
                var oCountry = oItem.getBindingContext("userModel").getObject();
                oLegalEntityCombo.getBinding("items").filter(
                    new Filter("country", FilterOperator.EQ, oCountry.code)
                );
                var aItems = oLegalEntityCombo.getAggregation("items");
                if (aItems.length === 1) {
                    oLegalEntityCombo.setSelectedItem(aItems[0]);
                }
            } else {
                oLegalEntityCombo.getBinding("items").filter([]);
            }
        },
        /**
         * Event handler for Legal Entity filter change event
         * based on the selected Legal Entity, country data will be filtered
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onChangeLegalEntity: function (oEvent) {
            var oItem = oEvent.getSource().getSelectedItem(),
                oCountryCombo = this.byId("scbCountryCombo");
            if (oItem) {
                var oLegalEntity = oItem.getBindingContext("userModel").getObject();
                oCountryCombo.getBinding("items").filter(
                    new Filter("code", FilterOperator.EQ, oLegalEntity.country)
                );
                var aItems = oCountryCombo.getAggregation("items");
                if (aItems.length === 1) {
                    oCountryCombo.setSelectedItem(aItems[0]);
                }
            } else {
                oCountryCombo.getBinding("items").filter([]);
            }

        },
        /**
         * Event handler for clear button press event
         * @param {sap.ui.base.event} oEvent 
         * @author Vijay Joshi
         * @changedate 05-11-2021
         */
        onPressClear: function (oEvent) {
            var oViewModel = this.getModel("hrViewModel");
            CommonUtil.onPressClear(oEvent, oViewModel, this);
        }
    });

});