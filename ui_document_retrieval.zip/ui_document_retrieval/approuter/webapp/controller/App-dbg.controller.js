sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "../model/formatter",
    "../utils/AppUtil"
], function (BaseController, JSONModel, Fragment, formatter, AppUtil) {
    "use strict";

    return BaseController.extend("org.sap.cap.scb.document.retreival.controller.App", {
        // default formatter for xml view
        formatter: formatter,
        /**
         * @author Vijay Joshi
         * @changedate 20-10-2021
         * Life cycle method
         */
        onInit: function () {
            var oViewModel,
                fnSetAppNotBusy,
                iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
            oViewModel = new JSONModel({
                busy: false,
                delay: 0,
                appTitle: this.getResourceBundle().getText("shell.empViewTitle"),
                layout: "OneColumn",
                previousLayout: "",
                configurations: [],
                dateRangeMaxValue: 0,
                dateFormat: "",
                prevRoute: "",
                actionButtonsInfo: {
                    midColumn: {
                        fullScreen: false
                    }
                }
            });
            this.setModel(oViewModel, "appView");

            //SFEC-17703 

           var oHRViewModel = new JSONModel({
                delay: 0,
                dateRangeMaxValue: 0,
                countries: [],
                legalEntities: [],
                showWarningMsg: false,
                IsHR: false
            });
            this.setModel(oHRViewModel, "hrViewModel");
            var empViewModel = new JSONModel({
                delay: 0,
                dateRangeMaxValue: 0,
                dateFormatter: "",
                showWarningMsg: false,
                IsHR: false
            });
            this.setModel(empViewModel, "empViewModel");
            //end of SFEC-17703 
            // get user info data
            var that = this, bHR = true, bEmployee = false,
                oUserModel = this.getOwnerComponent().getModel("userModel");

            // set usermodel initial data
            oUserModel.setData({});                                    
            // set Document model
            var oDocumentModel = new JSONModel({
                items: [],
                delay: 0,
                title: this.getResourceBundle().getText("documentlist.titleCount", [0]),
                noDataText: this.getResourceBundle().getText("documentList.noDataText"),
            });
            this.setModel(oDocumentModel, "document");

            fnSetAppNotBusy = function () {
                oViewModel.setProperty("/busy", false);
                oViewModel.setProperty("/delay", iOriginalBusyDelay);
            };

            // apply content density mode to root view
            this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
            // Get Configuration data
            AppUtil.getDefaultConfiguration(this);
        },
        /**         
         * Event handler for menu button press event
         * @author Vijay Joshi
         * @changeDate 20-10-2021
         * @param {sap.ui.base.event} oEvent 
         */
        onPressMenu: function (oEvent) {
            // var oView = this.getView(),
            //     oButton = oEvent.getSource();
            // if (!this._oMenuFragment) {
            //     this._oMenuFragment = Fragment.load({
            //         id: oView.getId(),
            //         name: "org.sap.cap.scb.document.retreival.view.fragments.UserMenu",
            //         controller: this
            //     }).then(function (oMenu) {
            //         this._oMenuFragment = oMenu;
            //         oView.addDependent(this._oMenuFragment);
            //         oMenu.openBy(oButton);
            //         return this._oMenuFragment;
            //     }.bind(this));
            // } else {
            //     this._oMenuFragment.openBy(oButton);
            // }
        },

        /**
         * Event handler for Employee view menu press
         * @author Vijay Joshi
         * @changeDate 20-10-2021
         * @param {sap.ui.base.event} oEvent 
         */
        onPressEmployee: function (oEvent) {
            this.getModel("appView").setProperty("/prevRoute", "");
            this.getRouter().navTo("MyDocuments");
            this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.empViewTitle"));
        },
        /**
         * Event handler for HR view menu press
         * @author Vijay Joshi
         * @changeDate 20-10-2021
         * @param {sap.ui.base.event} oEvent 
         */
        onPressHR: function (oEvent) {
            this.getModel("appView").setProperty("/prevRoute", "");
            this.getRouter().navTo("EmployeeDocuments");
            this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.hrViewTitle"));
        }        


    });
});