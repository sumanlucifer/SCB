sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.retreival.controller.UnAuthorized", {

		/**
		 * Initiate the controller and bind other event handler
		 * @author Vijay Joshi
         * @changedate 20-10-2021
		 */
		onInit: function () {
			this.getRouter().getTarget("unAuthorized").attachDisplay(this._onUnAuthorizedDisplayed, this);
		},
		/**
		 * Event Hanlder for Route match event
		 * @author Vijay Joshi
         * @changedate 20-10-2021
		 */
		_onUnAuthorizedDisplayed : function () {
			this.getModel("appView").setProperty("/layout", "OneColumn");
		}
	});
});