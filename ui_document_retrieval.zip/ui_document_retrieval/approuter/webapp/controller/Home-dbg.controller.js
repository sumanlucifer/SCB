sap.ui.define([
	"./BaseController","../utils/AppUtil"
], function (BaseController,AppUtil) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.retreival.controller.Home", {
		/**
		 * Initiate the home controller and bind other event handler
		 * @author Vijay Joshi
         * @changedate 20-11-2021
		 */
		onInit: function () {
            this.getRouter().getRoute("Home").attachPatternMatched(this._onHomeMatch, this);			
		},
		/**
		 * Event Hanlder for Route match event
		 * @author Vijay Joshi
         * @changedate 20-11-2021
		 */
		_onHomeMatch : function () {
			this.getModel("appView").setProperty("/layout", "OneColumn");
			var oUserModel = this.getModel("userModel");
			if (oUserModel.getProperty("/IsEmp")) {
				this.getRouter().navTo("MyDocuments");
			}else{
				AppUtil.getUserInfo(this).then(function(oRes){
					this.getRouter().navTo("MyDocuments",true);
				}.bind(this));
				this.getRouter().navTo("MyDocuments",true);
			}
		}
	});
});