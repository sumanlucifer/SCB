sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.retreival.controller.NotFound", {

		/**
		 * Initiate the controller and bind other event handler
		 * @author Vijay Joshi
         * @changedate 20-11-2021
		 */
		onInit: function () {
			this.getRouter().getTarget("notFound").attachDisplay(this._onNotFoundDisplayed, this);
		},
		/**
		 * Event Hanlder for Route match event
		 * @author Vijay Joshi
         * @changedate 20-11-2021
		 */
		_onNotFoundDisplayed : function () {
			this.getModel("appView").setProperty("/layout", "OneColumn");
		}
	});
});