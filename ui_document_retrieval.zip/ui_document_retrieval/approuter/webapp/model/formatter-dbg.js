sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Formatter method to format normal date to EPOCH date
		 * @param {Date} oDate 
		 * @author Vijay Joshi
         * @changedate 20-10-2021
		 * @returns 
		 */
		formateDatetoEPOCHDate: function (oDate) {
			if(oDate){
				var sEpochDate = parseFloat(oDate.getTime() / 1000).toFixed(0);
				return sEpochDate;
			}
			return oDate;
		}
	};
});