sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";

	return {

		/**
		 * Format the file size of bytes into MB
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		formatFileSize: function (sValue) {
			if (!sValue) {
				return parseFloat(0);
			}
			return parseFloat((sValue / (1024 * 1024)).toFixed(3));
		},
		/**
		 * Format the file size of bytes into MB
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		showFileSizeInMb: function (sValue) {
			var sMb=this.getModel("i18n").getProperty("upload.remainingSizeUnit");
			if (!sValue) {
				return "0 "+ sMb;
			}
			return parseFloat(sValue).toFixed(3).toString() + " " +sMb;
		},
		/**
		 * Format the Remaining Size text on UI
		 * @param {Integer} iRemainingSize 
		 * @returns 
		 */
		formatRemainingSizeText: function (iRemainingSize) {
			if (iRemainingSize < 1) {
				return 1;
			} else {
				return 7;
			}
		},
		/**
		 * Format Batch status icon text
		 * @param {string} sStatus 
		 * @returns 
		 */
		formatBatchStatusIcon: function (sStatus) {
			if (sStatus === "0") {
				return "sap-icon://process";
			} else if (sStatus === "1") {
				return "sap-icon://border";
			} else if (sStatus === "2") {
				return "sap-icon://status-error";
			} else {
				return "";
			}
		},
		/**
		 * Format Batch status state
		 * @param {string} sStatus 
		 * @returns 
		*/
		formatBatchStatusState: function (sStatus) {
			if (sStatus === "0") {
				return sap.ui.core.ValueState.Information;
			} else if (sStatus === "1") {
				return sap.ui.core.ValueState.Success;
			} else if (sStatus === "2") {
				return sap.ui.core.ValueState.Error;
			} else {
				return sap.ui.core.ValueState.None;
			}
		},
		/**
		 * Format Batch status state
		 * @param {string} sStatus 
		 * @returns 
		*/
		formatBatchRowState: function (sStatus) {
			if (sStatus === "1") {
				return sap.ui.core.ValueState.Success;
			} else if (sStatus === "2") {
				return sap.ui.core.ValueState.Error;
			} else {
				return sap.ui.core.ValueState.None;
			}
		},
		/**
		 * Format Batch status Text
		 * @param {string} sStatus 
		 * @returns 
		*/
		formatBatchStatusText: function (sStatus) {
			if (sStatus === "0") {
				return "In Progress";
			} else if (sStatus === "1") {
				return "Success";
			} else if (sStatus === "2") {
				return "Error";
			} else {
				return sStatus;
			}
		},
		/**
		 * Format Batch status icon text
		 * @param {string} sStatus 
		 * @returns 
		 */
		formatFileStatusIcon: function (sStatus) {
			if (sStatus === "Yes") {
				return "sap-icon://border";
			} else if (sStatus === "No") {
				return "sap-icon://status-error";
			} else {
				return "";
			}
		},
		/**
		 * Format Batch status state
		 * @param {string} sStatus 
		 * @returns 
		*/
		formatFileStatusState: function (sStatus) {
			if (sStatus === "Yes") {
				return sap.ui.core.ValueState.Success;
			} else if (sStatus === "No") {
				return sap.ui.core.ValueState.Error;
			} else {
				return sap.ui.core.ValueState.None;
			}
		},
		/**
		 * Format Batch status Text
		 * @param {string} sStatus 
		 * @returns 
		*/
		formatFileStatusText: function (sStatus) {
			if (sStatus === "Yes") {
				return "Success";
			} else if (sStatus === "No") {
				return "Error";
			} else {
				return "-";
			}
		},

		/**
		 * Formatter to format datetime value as per configuration datetime formatter
		 * @param {Datetime} oDate 
		 */
		formatDateValue: function (oDate) {
			var oAppModel = this.getModel("appView"),
				sDateFormat = oAppModel.getProperty("/dateFormat");
			if (oDate) {
				var oDateFormat = DateFormat.getDateTimeInstance({ pattern: sDateFormat }),
					oFormattedDate = oDateFormat.format(new Date(oDate));
				return oFormattedDate;
			}
			return oDate;
		}


	};

});