sap.ui.define(["../controller/ErrorHandler"
], function (ErrorHandler) {
    "use strict";

    return {
        /**
         * Method for generic GET call using AJAX
         * @param {string} sPath - path for rest call 
         * @param {object} that - this object of current view
         * @returns 
         */
        _GET: function (sPath, that) {
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: sPath,
                    success: function (oResponse) {
                        resolve(oResponse);
                    },
                    error: function (oError) {               
                        reject(oError);
                        this.showServiceError(oError,that);
                    }.bind(this)
                });
            }.bind(this));
        },
        /**
         * Method for generic GET call using AJAX
         * @param {string} sPath - path for rest call 
         * @param {object} oData - post call data object
         * @param {object} that - this object of current view
         * @returns 
         */
        _POST: function (sPath, oData, that) {
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    contentType: "application/json",
                    url: sPath,
                    data: JSON.stringify(oData),
                    success: function (oResponse) {
                        resolve(oResponse);
                    },
                    error: function (oError) {
                        reject(oError);
                        this.showServiceError(oError,that);
                    }.bind(this)
                });
            }.bind(this));
        },
        /**
         * Helper method to show service error if rest call failed
         * @param {object} oError 
         */
        showServiceError: function (oError,that) {
            // Show error message from the error handler
            var sErrorMsg = that.getResourceBundle().getText("errorText"),
                sDetailMsg = oError.responseText || oError.statusText;
            that.getOwnerComponent()._oErrorHandler._showServiceError(sErrorMsg, sDetailMsg);
        }
    };
});