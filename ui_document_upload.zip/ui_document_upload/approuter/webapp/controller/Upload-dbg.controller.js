sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/m/MessageBox",
    "../utils/AppUtil",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "../utils/RestCallUtils",
    "sap/ui/core/Fragment",
    "../utils/Constants",
], function (BaseController, JSONModel, History, formatter, MessageBox, AppUtil, Filter, FilterOperator, RestCallUtils, Fragment,Constants) {
    "use strict";

    return BaseController.extend("org.sap.cap.scb.document.upload.controller.Upload", {
        // xml formatter
        formatter: formatter,
        /**
         * Called when the controller is instantiated.
         * @author Vijay Joshi
         * @changedate 06-12-2021
         */
        onInit: function () {
            var oViewModel = new JSONModel();
            this.setModel(oViewModel, "upload");
            this.getRouter().getRoute("Upload").attachPatternMatched(this._onObjectMatched, this);
        },
        /**
         * Binds the view to the object path.
         * @function
         * @author Vijay Joshi
         * @changedate 06-12-2021
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        _onObjectMatched: function (oEvent) {
            var oUserModel = this.getModel("userModel"),
                oUploadModel = this.getModel("upload");
            if (oUserModel.getProperty("/IsHR")) {
                oUploadModel.setData(this.setViewModel());
            } else {
                AppUtil.getUserInfo(this).then(function (oRes) {
                    oUploadModel.setData(this.setViewModel());
                }.bind(this))
            }
            this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.startUpload"));
        },
        /**
         * Helper method to set view model
         * @author Vijay Joshi
         * @changedate 07-12-2021
         * @returns object
         */
        setViewModel: function () {
            var oAppModel = this.getModel("appView");
            return {
                busy: false,
                delay: 0,
                Files: [],
                showWarningMsg: false,
                headerText: this.getResourceBundle().getText("uploadDocList.titleCount", [0]),
                allowedFileSize: oAppModel.getProperty("/maxFileSize"),
                remaningFileSize: oAppModel.getProperty("/maxFileSize"),
                enableAttachFile: false,
                enableUploadFile: false,
                messageStripText: this.getResourceBundle().getText("upload.warningMsg", [oAppModel.getProperty("/allowedFiles"), oAppModel.getProperty("/maxFileSize")]),
                docTypeValueStateText: "",
                docTypeValueState: sap.ui.core.ValueState.None,
                dateValueStateText: "",
                dateValueState: sap.ui.core.ValueState.None,
                legalEntityValueStateText: "",
                legalEntityValueState: sap.ui.core.ValueState.None,
                countryValueStateText: "",
                countryValueState: sap.ui.core.ValueState.None,
                docTypeValue: "",
                dateValue: null,
                legalEntityValue: "",
                countryValue: "",
                validUpload: false,
                tableMode: "None",
                showDeleteMultiple: false,
                showDeleteSelected: false,
                enableDeleteSelected: false
            };
        },
        /**
         * Event Handler for Upload button press
         * @author Vijay Joshi
         * @changedate 03-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onPressUpload: async function (oEvent) {
            var oUploadModel = this.getModel("upload"),
                aFiles = oUploadModel.getProperty("/Files");
            try {
                oUploadModel.setProperty("/busy", true);
                const filePathsPromises = [], aFileArray = [];
                aFiles.forEach(oFile => {
                    filePathsPromises.push(this.convertToBase64(oFile.file));
                    aFileArray.push({
                        "fileName": oFile.file.name,
                        "fileSize": formatter.formatFileSize(oFile.file.size),
                        "file": ""
                    });
                });
                const filePaths = await Promise.all(filePathsPromises);
                const mappedFiles = filePaths.map((base64File) => ({ selectedFile: base64File }));
                for (var i in mappedFiles) {
                    aFileArray[i].file = mappedFiles[i].selectedFile;
                }
                // console.log(aFileArray);
                this.uploadFiles(aFileArray);
            }
            catch (oErr) {
                oUploadModel.setProperty("/busy", false);
            }
        },
        /**
         * Helper method to convert file into Base64 string
         * @author Vijay Joshi
         * @changedate 03-01-2022
         * @param {object} file 
         * @returns 
         */
        convertToBase64: function (file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => resolve(reader.result);
                reader.onerror = error => reject(error);
            });
        },
        /**
         * Helper method to upload the files into server using Ajax call
         * @author Vijay Joshi
         * @changedate 03-01-2022
         * @param {array} aFiles 
         */
        uploadFiles: function (aFiles) {
            var oAppModel = this.getModel("appView"),
                oUploadModel = this.getModel("upload");
            var oData = {
                "country": oUploadModel.getProperty("/countryValue"),
                "legalEntity": oUploadModel.getProperty("/legalEntityValue"),
                "docType": oUploadModel.getProperty("/docTypeValue"),
                "date": oUploadModel.getProperty("/dateValue"),
                "fileList": aFiles
            };
            var sUrl = Constants.API_UPLOAD_FILE;
            RestCallUtils._POST(sUrl, oData, this).then(function (oRes) {
                oUploadModel.setProperty("/busy", false);
                this.resetFiles();
                var sMsg = this.getResourceBundle().getText("upload.successMsg");
                MessageBox.success(sMsg, {
                    styleClass: this.getOwnerComponent().getContentDensityClass()
                });
            }.bind(this)).
                catch(function (oError) {
                    oUploadModel.setProperty("/busy", false);
                }.bind(this));
        },
        /**
         * Event handler for AttachFiles button press
         * @author Vijay Joshi
         * @changedate 05-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        attachFiles: function (oEvent) {
            var oAppModel = this.getModel("appView"),
                oUploadModel = this.getModel("upload"), sMsg,
                oFileList = oEvent.getParameter("files"),
                aFiles = Array.from(oFileList),
                iLength = aFiles.length,
                aFileList = oUploadModel.getProperty("/Files"),
                iAllowedFileSize = oUploadModel.getProperty("/allowedFileSize"),
                iRemaningFileSize = oUploadModel.getProperty("/remaningFileSize"),
                bValidFile = true, bValidUpload = true;
            if (aFiles && aFiles.length && aFiles.length > 0) {
                oUploadModel.setProperty("/busy", true);
                var aAttachedFileSize = aFileList.map(oFile => oFile.file.size),
                    aSelectedFileSize = aFiles.map(file => file.size), iAttachedFileSize = 0, iSelectedFileSize = 0;
                if (aAttachedFileSize && aAttachedFileSize.length && aAttachedFileSize.length > 0) {
                    iAttachedFileSize = aAttachedFileSize.reduce((prev, next) => prev + next);
                }
                if (aSelectedFileSize && aSelectedFileSize.length && aSelectedFileSize.length > 0) {
                    iSelectedFileSize = aSelectedFileSize.reduce((prev, next) => prev + next);
                }
                var iTotalFileSize = formatter.formatFileSize(iAttachedFileSize) + formatter.formatFileSize(iSelectedFileSize);
                // logic to check if the total of attached file size and selected file size are exceeding  
                // the size limit (e.g.5 MB) or not
                if (iTotalFileSize > iAllowedFileSize) {
                    sMsg = this.getResourceBundle().getText("upload.fileSizeExceedMsg", [iAllowedFileSize]);
                    MessageBox.warning(sMsg, {
                        styleClass: this.getOwnerComponent().getContentDensityClass()
                    });
                } else {
                    iRemaningFileSize = iAllowedFileSize - iTotalFileSize;
                    var aFileNames = aFileList.map(oFile => oFile.file.name),
                        sFileName, aNames, bValidationFail = true;
                    for (var iFile = 0; iFile < iLength; iFile++) {
                        sFileName = aFiles[iFile].name;
                        aNames = sFileName.split("_");
                        if (aFileNames.indexOf(sFileName) >= 0) {
                            sMsg = this.getResourceBundle().getText("upload.fileAlreadyAddedMsg", [sFileName]);
                            MessageBox.warning(sMsg, {
                                styleClass: this.getOwnerComponent().getContentDensityClass()
                            });
                            oUploadModel.setProperty("/busy", false);
                            return;
                        }
                        // logic for validation
                        var oFileValidation = this._validateFile(sFileName);
                        if (!oFileValidation.valid) {
                            bValidationFail = false;
                        }
                        aFileList.push({
                            file: aFiles[iFile],
                            validFile: oFileValidation.valid,
                            messages: oFileValidation.msg
                        });
                    }
                    bValidUpload = (bValidationFail && aFileList.length > 0);
                    var bIsDelete = false;
                    this.setValidUpload(bValidUpload, aFileList, iRemaningFileSize, bIsDelete);
                    oUploadModel.setProperty("/validUpload", bValidUpload);
                    oUploadModel.setProperty("/Files", aFileList);
                    oUploadModel.setProperty("/showDeleteSelected", false);                    
                }
                oUploadModel.setProperty("/busy", false);
            }
        },
        /**
         * This is helper method to validate the file name
         * @author Vijay Joshi
         * @changedate 10-02-2022
         * @param {string} sFileName 
         * @returns 
         */
        _validateFile: function (sFileName) {
            var oViewModel = this.getModel("upload"),
                oRM = this.getResourceBundle(),
                oValid = {
                    valid: true,
                    msg: []
                };
            //var aFilenameTexts = sFileName.split("_");
            var aFilenameTexts = sFileName.substring(0,sFileName.lastIndexOf('.')).split("_");
            if (aFilenameTexts && aFilenameTexts.length && aFilenameTexts.length > 0) {
                try {
                    var iAllowedFileNameLength = this.getModel("appView").getProperty("/fileNameMaxLength");
                    if (sFileName.length > iAllowedFileNameLength) {
                        bValid = false;
                        oValid.msg.push(
                            { "text": oRM.getText("upload.filenameExceedError", [iAllowedFileNameLength]) }
                        );
                    }
                    var bValid = true;
                    //logic to restrict space in file name
                    if(sFileName.indexOf(' ')>0){
                        bValid = false;
                        oValid.msg.push(
                            { "text": oRM.getText("upload.fileNameHasSpaceError") }
                        );
                    }
                    var sBankId = aFilenameTexts[0],
                        sLegalEntity = aFilenameTexts[1],
                        sDate = aFilenameTexts[2];
                    
                    if (isNaN(sBankId)) {
                        bValid = false;
                        oValid.msg.push(
                            { "text": oRM.getText("upload.fileNameInvalidBankIdMsg") }
                        );
                    }
                    if (sLegalEntity && oViewModel.getProperty("/legalEntityValue") !== sLegalEntity) {
                        bValid = false;
                        oValid.msg.push(
                            { "text": oRM.getText("upload.fileNameInvalidLegalEntityMsg") }
                        );
                    }
                    var oUploadDate = oViewModel.getProperty("/dateValue"),
                        sFormattedDate = oUploadDate.replaceAll("/", "");
                    if (sDate && sFormattedDate !== sDate) {
                        bValid = false;
                        oValid.msg.push(
                            { "text": oRM.getText("upload.fileNameInvalidDateMsg") }
                        );
                    }
                    oValid.valid = bValid;
                } catch (oError) {
                    oValid.valid = false;
                    oValid.msg.push({ "text": oRM.getText("upload.fileNameInvalidMsg") });
                }
            } else {
                oValid.valid = false;
                oValid.msg.push({ "text": oRM.getText("upload.fileNameInvalidMsg") });
            }
            return oValid;
        },
        /**
         * Event handler for delete button press
         * @author Vijay Joshi
         * @changedate 04-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onDeleteFileItem: function (oEvent) {
            var oFile = oEvent.getSource().getBindingContext("upload").getObject(),
                sMsg = this.getResourceBundle().getText("upload.deleteConfirmation")
            MessageBox.confirm(sMsg, {
                styleClass: this.getOwnerComponent().getContentDensityClass(),
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        var oUploadModel = this.getModel("upload"),
                            iRemaningFileSize = oUploadModel.getProperty("/remaningFileSize"),
                            aFiles = oUploadModel.getProperty("/Files");
                        var iIndex = aFiles.indexOf(oFile);
                        aFiles.splice(iIndex, 1);
                        oUploadModel.setProperty("/Files", aFiles);
                        var bValidUpload = (aFiles.filter(file => file.validFile === false).length > 0 ? false : true);
                        bValidUpload = (bValidUpload && aFiles.length > 0)
                        iRemaningFileSize += formatter.formatFileSize(oFile.file.size);
                        var bIsDelete = true;
                        this.setValidUpload(bValidUpload, aFiles, iRemaningFileSize, bIsDelete);                        
                    }
                }.bind(this)
            });
        },
        /**
         * Event handler for document type change event
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onDocumentTypeChange: function (oEvent) {
            var oRM = this.getResourceBundle(),
                oSource = oEvent.getSource(),
                sValue = oSource.getSelectedKey();
            if (sValue.trim() === "") {
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oRM.getText("uploadfilter.documentType")]));
            } else {
                oSource.setValueState(sap.ui.core.ValueState.None);
                oSource.setValueStateText("");
            }
            this.enableAttachFileButton(oEvent);
        },
        /**
         * Event handler for country filter change event
         * based on the selected country, legal entity data will be filtered
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onChangeCountry: function (oEvent) {
            var oRM = this.getResourceBundle(),
                oSource = oEvent.getSource(),
                oItem = oSource.getSelectedItem(),
                oLegalEntityCombo = this.byId("idLegalEntityCombo");
            if (oItem) {
                var oCountry = oItem.getBindingContext("userModel").getObject();
                oLegalEntityCombo.getBinding("items").filter(
                    new Filter("country", FilterOperator.EQ, oCountry.code)
                );
                var aItems = oLegalEntityCombo.getAggregation("items");
                if (aItems && aItems.length && aItems.length === 1) {
                    oLegalEntityCombo.setSelectedItem(aItems[0]);
                } else {
                    oLegalEntityCombo.setSelectedItem(null);
                    oLegalEntityCombo.setSelectedKey(null);
                }
                oLegalEntityCombo.setValueState(sap.ui.core.ValueState.None);
                oLegalEntityCombo.setValueStateText("");
                oSource.setValueState(sap.ui.core.ValueState.None);
                oSource.setValueStateText("");
            } else {
                oLegalEntityCombo.getBinding("items").filter([]);
                oLegalEntityCombo.setSelectedItem(null);
                oLegalEntityCombo.setSelectedKey(null);
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oRM.getText("uploadfilter.country")]));
            }
            this.enableAttachFileButton(oEvent);
        },
        /**
         * Event handler for Legal Entity filter change event
         * based on the selected Legal Entity, country data will be filtered
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onChangeLegalEntity: function (oEvent) {
            var oRM = this.getResourceBundle(),
                oUploadModel = this.getModel("upload"),
                oSource = oEvent.getSource(),
                oItem = oSource.getSelectedItem(),
                oCountryCombo = this.byId("idCountryCombo");
            if (oItem) {
                var oLegalEntity = oItem.getBindingContext("userModel").getObject();
                oCountryCombo.setSelectedKey(oLegalEntity.country);
                oCountryCombo.setValueState(sap.ui.core.ValueState.None);
                oCountryCombo.setValueStateText("");
                oSource.setValueState(sap.ui.core.ValueState.None);
                oSource.setValueStateText("");
            } else {
                oSource.setValueState(sap.ui.core.ValueState.Error);
                oSource.setValueStateText(oRM.getText("filterbar.fieldMandatoryMsg", [oRM.getText("uploadfilter.legalEntity")]));
                oCountryCombo.getBinding("items").filter([]);
            }
            this.enableAttachFileButton(oEvent);
        },
        /**
         * Event handler for date range filter selection change
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent - event object
         */
        onDateChange: function (oEvent) {
            this.enableAttachFileButton(oEvent);
        },
        /**
         * Helper method for enable attach file button if all the mandatory parameter are filled 
         * @author Vijay Joshi
         * @changedate 10-01-2022 
         * @param {sap.ui.base.event} oEvent - event object    
         */
        enableAttachFileButton: function (oEvent) {
            var oUploadModel = this.getModel("upload"),
                sDocTypeValue = oUploadModel.getProperty("/docTypeValue"),
                oDateValue = oUploadModel.getProperty("/dateValue"),
                sLegalEntityValue = oUploadModel.getProperty("/legalEntityValue"),
                sCountryValue = oUploadModel.getProperty("/countryValue");
            if (sDocTypeValue && oDateValue && sLegalEntityValue && sCountryValue) {
                oUploadModel.setProperty("/enableAttachFile", true);
                oUploadModel.setProperty("/enableUploadFile", oUploadModel.getProperty("/Files").length > 0 ? true : false);
            }
            else {
                oUploadModel.setProperty("/enableAttachFile", false);
                oUploadModel.setProperty("/enableUploadFile", false);
            }

            // if filter crateria is changed after attaching the file
            // then show warning message to user
            if (oEvent.getSource().getValue() !== "" && oUploadModel.getProperty("/Files").length > 0) {
                var sMsg = this.getResourceBundle().getText("upload.filterCriteriaChangeMsg");
                MessageBox.warning(sMsg, {
                    styleClass: this.getOwnerComponent().getContentDensityClass()
                });
                // Validate the List item again and show error
                this._validFileItems();
            }
        },
        /**
         * @author Vijay Joshi
         * @changedate 11-02-2022
         * Helper method to validate the file items when filter criteria changes
         */
        _validFileItems: function () {
            var oUploadModel = this.getModel("upload"),
                oItem, bItemsValid = true,
                aFileItems = oUploadModel.getProperty("/Files");
            for (var iFile = 0; iFile < aFileItems.length; iFile++) {
                oItem = aFileItems[iFile];
                var oFileValid = this._validateFile(oItem.file.name);
                if (!oFileValid.valid) {
                    bItemsValid = false;
                }
                oItem.validFile = oFileValid.valid;
                oItem.messages = oFileValid.msg;
            }
            oUploadModel.setProperty("/Files", aFileItems)
            oUploadModel.setProperty("/validUpload", bItemsValid);
            oUploadModel.setProperty("/enableUploadFile", bItemsValid);
            oUploadModel.refresh(true);
        },
        /**
         * Event Handler for clear button press event
         * This function will clear all the data from filterbar and attached files
         * @author Vijay Joshi
         * @changedate 11-02-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onClearPress: function (oEvent) {
            var sMsg = this.getResourceBundle().getText("upload.clearConfirmation");
            MessageBox.confirm(sMsg, {
                styleClass: this.getOwnerComponent().getContentDensityClass(),
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        var oUploadModel = this.getModel("upload"),
                            oLegalEntityCombo = this.byId("idLegalEntityCombo");
                        oUploadModel.setData(this.setViewModel());
                        oLegalEntityCombo.getBinding("items").filter([]);
                    }
                }.bind(this)
            });
        },
        /**
         * Event handler for file type mismatch event
         * This event is fired when there is mismatch in selected file type 
         * with allowed file type
         * @author Vijay Joshi
         * @changedate 11-02-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onFileTypeMissMatch: function (oEvent) {
            var sMsg = this.getResourceBundle().getText("upload.fileTypeMissMatchError");
            MessageBox.warning(sMsg, {
                styleClass: this.getOwnerComponent().getContentDensityClass()
            });
        },
        /**
         * Event handler for warning icon press event in table items
         * This method is used to display the error message for the uploaded file
         * @author Vijay Joshi
         * @changedate 11-02-2022
         * @param {sap.ui.base.event} oEvent 
         */
        handlePopoverPress: function (oEvent) {
            var oCtx = oEvent.getSource().getBindingContext("upload"),
                oControl = oEvent.getSource(),
                oView = this.getView();

            // create popover
            if (!this._pPopover) {
                this._pPopover = Fragment.load({
                    id: oView.getId(),
                    name: "org.sap.cap.scb.document.upload.view.fragments.WarningMsgPopover",
                    controller: this
                }).then(function (oPopover) {
                    oView.addDependent(oPopover);
                    return oPopover;
                }.bind(this));
            }
            this._pPopover.then(function (oPopover) {
                oPopover.bindElement("upload>" + oCtx.getPath());
                oPopover.openBy(oControl);
            });
        },
        /**
         * Helper method to reset attached files and counter after successful save
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @returns 
         */
        resetFiles: function () {
            var oAppModel = this.getModel("appView"),
                oUploadModel = this.getModel("upload");
            oUploadModel.setProperty("/Files", []);
            oUploadModel.setProperty("/headerText", this.getResourceBundle().getText("uploadDocList.titleCount", [0]));
            oUploadModel.setProperty("/remaningFileSize", oAppModel.getProperty("/maxFileSize"));
            oUploadModel.setProperty("/enableAttachFile", true);
            oUploadModel.setProperty("/enableUploadFile", false);
            oUploadModel.setProperty("/validUpload", false);
            oUploadModel.setProperty("/tableMode", "None");
            oUploadModel.setProperty("/showDeleteMultiple", false);
            oUploadModel.setProperty("/showDeleteSelected", false);
            oUploadModel.setProperty("/enableDeleteSelected", false);
        },
        /**
         * Event handler for Delete Multiple Button
         * This method used to enable the multiselect mode on the table and
         * show the Delete selected Button
         * @author Vijay Joshi
         * @changedate 10-02-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onPressEnableMultiple: function (oEvent) {
            var oUploadModel = this.getModel("upload");
            oUploadModel.setProperty("/tableMode", "MultiSelect");
            oUploadModel.setProperty("/showDeleteSelected", true);
            oUploadModel.refresh(true);
        },
        /**
         * Event handler for Delete Multiple Button
         * This method used to enable the multiselect mode on the table and
         * show the Delete selected Button
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onPressDisableMultiple: function (oEvent) {
            var oUploadModel = this.getModel("upload");
            oUploadModel.setProperty("/tableMode", "None");
            oUploadModel.setProperty("/showDeleteSelected", false);
            oUploadModel.refresh(true);
        },
        /**
         * Event handler for Delete Selected Button
         * This method used to delete selected items 
         * @author Vijay Joshi
         * @changedate 11-02-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onPressDeleteSelected: function (oEvent) {
            var sMsg = this.getResourceBundle().getText("upload.deleteConfirmation");
            MessageBox.confirm(sMsg, {
                styleClass: this.getOwnerComponent().getContentDensityClass(),
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        var oTable = this.byId("idUploadFilesTable"),
                            aSelectedItems = oTable.getSelectedItems(),
                            oUploadModel = this.getModel("upload"),
                            aFiles = oUploadModel.getProperty("/Files"),
                            iIndex, oFile,
                            iRemaningFileSize = oUploadModel.getProperty("/remaningFileSize");
                        for (var iItem = aSelectedItems.length - 1; iItem >= 0; iItem--) {
                            oFile = aSelectedItems[iItem].getBindingContext("upload").getObject();
                            iIndex = aFiles.indexOf(oFile);
                            aFiles.splice(iIndex, 1);
                            iRemaningFileSize += formatter.formatFileSize(oFile.file.size);
                        }
                        oUploadModel.setProperty("/Files", aFiles);
                        // set the attach file button visible based on the valid upload or not
                        var bValidUpload = (aFiles.filter(file => file.validFile === false).length > 0 ? false : true);
                        bValidUpload = (bValidUpload && aFiles.length > 0);
                        var bIsDelete = true;
                        this.setValidUpload(bValidUpload, aFiles, iRemaningFileSize, bIsDelete);
                        if(aFiles.length === 0){
                            oUploadModel.setProperty("/tableMode", "None"); 
                        }
                        // dont change state utill use choose, only if there is not files then change the state
                        oUploadModel.setProperty("/showDeleteSelected", false);
                        oUploadModel.setProperty("/enableDeleteSelected", false);
                        oTable.removeSelections(true);
                        oUploadModel.refresh(true);
                    }
                }.bind(this)
            });
        },
        /**
         * Helper method for set common property
         * @author Vijay Joshi
         * @changedate 18-02-2022
         * @param {boolean} bValidUpload 
         * @param {array} aFiles 
         * @param {integer} iRemaningFileSize 
         * @param {boolean} bIsDelete 
         */
        setValidUpload: function (bValidUpload, aFiles, iRemaningFileSize, bIsDelete) {
            var oUploadModel = this.getModel("upload");
            if (bIsDelete === true) {
                oUploadModel.setProperty("/remaningFileSize", aFiles.length > 0 ? iRemaningFileSize : oUploadModel.getProperty("/allowedFileSize"));
                oUploadModel.setProperty("/enableUploadFile", bValidUpload);
                oUploadModel.setProperty("/headerText", this.getResourceBundle().getText("uploadDocList.titleCount", [aFiles.length]));
                oUploadModel.setProperty("/showDeleteMultiple", (aFiles.length > 0));
            }
            else {
                oUploadModel.setProperty("/remaningFileSize", iRemaningFileSize);
                oUploadModel.setProperty("/enableUploadFile", bValidUpload);
                oUploadModel.setProperty("/showDeleteMultiple", true);
                oUploadModel.setProperty("/headerText", this.getResourceBundle().getText("uploadDocList.titleCount", [aFiles.length]));
            }
        },
        /**
         * Event handler for table selection change
         * This method is used to enable or disable the multi delete button
         * @author Vijay Joshi
         * @changedate 10-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onTableSelectionChange: function (oEvent) {
            var oUploadModel = this.getModel("upload"),
                aItems = oEvent.getSource().getSelectedItems();
            if (aItems && aItems.length && aItems.length > 0) {
                oUploadModel.setProperty("/enableDeleteSelected", true);
            } else {
                oUploadModel.setProperty("/enableDeleteSelected", false);
            }
        },
        /**
         * Event handler for action item button press event
         * This method will use to open action items
         * @author Vijay Joshi
         * @changedate 24-01-2022
         * @param {sap.ui.base.event} oEvent 
         */
        onPressMoreInfo: function (oEvent) {
            var oButton = oEvent.getSource();
            this.byId("idActionSheet").openBy(oButton);
        }
    });

});