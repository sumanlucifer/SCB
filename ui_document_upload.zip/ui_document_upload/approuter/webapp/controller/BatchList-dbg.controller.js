sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../utils/RestCallUtils",
	"../utils/AppUtil",
	"../utils/Constants"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, RestCallUtils, AppUtil,Constants) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.upload.controller.BatchList", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the controller is instantiated.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 */
		onInit: function () {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._oFilterState = {
				aSearch: [],
				aFilter: [],
				aDefault: []
			};

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				batchlistTableTitle: this.getResourceBundle().getText("batchlistTableTitle", [0]),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("batch.noDataText"),
				tableBusyDelay: 0,
				delay: 0,
				busy: true,
				BatchName: "",
				Status: ""
			});
			this.setModel(oViewModel, "batchlistView");
			this.getRouter().getRoute("Batches").attachPatternMatched(this._onObjectMatched, this);
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},
		/**
		 * Event handler for Route match event
		 * @author Vijay Joshi
		 * @changedate 15-11-2021
		 * @param {sap.ui.base.event} oEvent 
		 */
		_onObjectMatched: function (oEvent) {
			var oUserModel = this.getModel("userModel"),
				sBankId = oUserModel.getProperty("/BankId");
			if (oUserModel.getProperty("/IsHR")) {
				var aDefaultFilter = [new Filter("createdBy", FilterOperator.Contains, sBankId)];
				this._oFilterState.aDefault = aDefaultFilter;
				this._applySearch();
			} else {
				AppUtil.getUserInfo(this).then(function (oRes) {
					sBankId = oUserModel.getProperty("/BankId");
					var aDefaultFilter = [new Filter("createdBy", FilterOperator.Contains, sBankId)];
					this._oFilterState.aDefault = aDefaultFilter;
					this._applySearch();
				}.bind(this))
			}
			this.getBatchStatus();
			this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.monitorUpload"));
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @author Vijay Joshi
		 * @changedate 15-11-2021
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 */
		onUpdateFinished: function (oEvent) {
			// update the object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("batchlistTableTitle", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("batchlistTableTitle", [0]);
			}
			this.getModel("batchlistView").setProperty("/batchlistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @author Vijay Joshi
		 * @changedate 15-11-2021
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 */
		onPressItem: function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @author Vijay Joshi
		 * @changedate 23-11-2021
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 */
		_showObject: function (oItem) {
			this.getRouter().navTo("BatchDetail", {
				objectId: oItem.getBindingContext("uploadModel").getPath().substring("/Batches".length)
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @author Vijay Joshi
		 * @changedate 23-11-2021
		 */
		_applySearch: function () {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("batchlistView");

			var aFilters = this._oFilterState.aDefault;
			aFilters = aFilters.concat(this._oFilterState.aFilter);
			aFilters = aFilters.concat(this._oFilterState.aSearch);
			oTable.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("batch.noDataTextWithSearch"));
			}
		},
		/**
		 * Helper method to get Batch status for filter drop down
		 * This method will get the Batch status data using Rest Call
		 * @author Vijay Joshi
		 * @changedate 23-11-2021
		 */
		getBatchStatus: function () {
			var oAppView = this.getModel("appView"),
				oBatchlistView = this.getModel("batchlistView");
			var sUrl = Constants.API_BATCH_STATUS;
			oBatchlistView.setProperty("/busy", true);
			RestCallUtils._GET(sUrl, this).then(function (oRes) {
				oAppView.setProperty("/Status", oRes)
				oBatchlistView.setProperty("/busy", false);
			}.bind(this)).
				catch(function (oError) {
					oBatchlistView.setProperty("/busy", false);
				}.bind(this));
		},
		/**
		 * Event handler for search button
		 * @author Vijay Joshi
		 * @changedate 23-11-2021
		 * @param {sap.ui.base.event} oEvent 
		 */
		onSearchPress: function (oEvent) {
			var oBatchlistView = this.getModel("batchlistView"),
				sBatchName = oBatchlistView.getProperty("/BatchName"),
				sStatus = oBatchlistView.getProperty("/StatusCode");
			var aFilters = [];
			if (sBatchName) {
				aFilters.push(new Filter(
					{
						path: 'batchName',
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sBatchName,
						caseSensitive: false
					}));
			}
			if (sStatus) {
				aFilters.push(new Filter("status", FilterOperator.EQ, sStatus));
			}
			this._oFilterState.aFilter = aFilters;
			this._applySearch();
		},
		/**
		 * Event handler for clear button press event
		 * @author Vijay Joshi
		 * @changedate 23-11-2021
		 * @param {sap.ui.base.event} oEvent 
		 */
		onPressClear: function (oEvent) {
			var oBatchlistView = this.getModel("batchlistView");
			oBatchlistView.setProperty("/BatchName", "");
			oBatchlistView.setProperty("/StatusCode", "");
			this._oFilterState.aFilter = [];
			this._applySearch();
		}
	});
});