sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../utils/AppUtil",
    "../utils/Constants"
], function (BaseController, JSONModel, AppUtil,Constants) {
    "use strict";

    return BaseController.extend("org.sap.cap.scb.document.upload.controller.App", {

        /**
         * @author Vijay Joshi
         * @changedate 03-11-2021
         * Life cycle method
         */
        onInit: function () {
            var oViewModel = new JSONModel({
                busy: false,
                delay: 0,
                layout: "OneColumn",
                appTitle: this.getResourceBundle().getText("shell.startUpload"),
                Configurations: [],
                maxRecordLength: Constants.MAX_RECORD_FOR_COMBOBOX                
            });
            this.setModel(oViewModel, "appView");
            // apply content density mode to root view
            this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
            // Load default configuration
            AppUtil.getDefaultConfiguration(this);
        },

        /**
         * Event handler for Employee view menu press
         * @author Vijay Joshi 
         * @changeDate 03-11-2021  
         * @param {sap.ui.base.event} oEvent 
         */
        onPressUpload: function (oEvent) {
            this.getRouter().navTo("Upload");
            this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.startUpload"));
        },
        /**
         * Event handler for HR view menu press
         * @author Vijay Joshi
         * @changeDate 03-11-2021
         * @param {sap.ui.base.event} oEvent 
         */
        onPressMonitorBatch: function (oEvent) {
            this.getRouter().navTo("Batches");
            this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.monitorUpload"));
        }
    });

});