sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.upload.controller.NotFound", {

		/**
		 * Navigates to the worklist when the link is pressed
		 * @author Vijay Joshi
         * @changedate 06-12-2021
		 */
		onLinkPressed : function () {
			this.getRouter().navTo("worklist");
		}
	});

});