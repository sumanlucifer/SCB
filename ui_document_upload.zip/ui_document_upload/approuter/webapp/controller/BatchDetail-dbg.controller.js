sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
	"../utils/AppUtil",
	"../utils/RestCallUtils",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"../utils/Constants"
], function (BaseController, JSONModel, History, formatter, AppUtil, RestCallUtils, Filter, FilterOperator, Fragment,Constants) {
	"use strict";

	return BaseController.extend("org.sap.cap.scb.document.upload.controller.BatchDetail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the controller is instantiated.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 * @public
		 */
		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: true,
				delay: 0,
				batchdetailTableTitle: this.getResourceBundle().getText("batchdetail.filesTitle", [0]),
				sFileNameSearch: ""
			});

			this.getRouter().getRoute("BatchDetail").attachPatternMatched(this._onObjectMatched, this);
			this.setModel(oViewModel, "objectView");
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		
		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the route.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 */
		onNavPress: function () {
			this.getRouter().navTo("Batches", {}, true);
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 */
		_onObjectMatched: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			var oUserModel = this.getModel("userModel");
			if (oUserModel.getProperty("/IsHR")) {
				this._bindView("uploadModel>/Batches" + sObjectId);
			} else {
				AppUtil.getUserInfo(this).then(function (oRes) {
					this._bindView("uploadModel>/Batches" + sObjectId);
				}.bind(this))
			}
			this.getModel("appView").setProperty("/appTitle", this.getResourceBundle().getText("shell.monitorUpload"));
			this.byId("scbBatchFileList").getBinding("items").filter([]);
			this.byId("vsdFilterBar").setVisible(false);
			this.byId("vsdFilterLabel").setText("");
			this.getBatchStatus();
			if (this.viewSettingsDialog) {
				this.viewSettingsDialog.destroy();
				delete this.viewSettingsDialog;
			}
		},
		/**
		 * Helper method to get Batch status for filter drop down
		 * This method will get the Batch status data using Rest Call
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 */
		getBatchStatus: function () {
			var oAppView = this.getModel("appView"),
				oViewModel = this.getModel("objectView");
			var sUrl = Constants.API_USER_INFO;
			oViewModel.setProperty("/busy", true);
			RestCallUtils._GET(sUrl, this).then(function (oRes) {
				oAppView.setProperty("/Status", oRes)
				oViewModel.setProperty("/busy", false);
			}.bind(this)).
				catch(function (oError) {
					oViewModel.setProperty("/busy", false);
				}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 */
		_bindView: function (sObjectPath) {
			var oViewModel = this.getModel("objectView");
			var sExpand = "files";
			this.getView().bindElement({
				path: sObjectPath,
				parameters: {
					$expand: sExpand
				},
				events: {
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 */
		onUpdateFinished: function (oEvent) {
			// update the object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("batchdetail.filesTitle", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("batchdetail.filesTitle", [0]);
			}
			this.getModel("objectView").setProperty("/batchdetailTableTitle", sTitle);
		},

		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 * @param {sap.ui.base.Event} oEvent the button press event
		 */
		onOpenViewSettings: function (oEvent) {
			if (!this.viewSettingsDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "org.sap.cap.scb.document.upload.view.fragments.FileFilterDialog",
					controller: this
				}).then(function (oDialog) {
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					oDialog.open();
					this.viewSettingsDialog = oDialog;
				}.bind(this));
			} else {
				this.viewSettingsDialog.open();
			}			
		},

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 */
		onConfirmViewSettingsDialog: function (oEvent) {
			this._applyFilter(oEvent);
		},
		/**
		 * Event handler for View setting Dialog's Reset filter press event
		 * @author Vijay Joshi
		 * @changeddate 24-01-2022
		 * @param {sap.ui.base.event} oEvent 
		 */
		onResetFilters: function (oEvent) {
			var oViewModel = this.getModel("objectView");
			oViewModel.setProperty("/filenameFilterValue", "");
		},
		/**
		 * Apply the chosen filter to the file list
		 * @author Vijay Joshi
		 * @changedate 09-11-2021
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @private
		 */
		_applyFilter: function (oEvent) {
			var oTable = this.byId("scbBatchFileList"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				oViewModel = this.getModel("objectView"),
				sFileNameSearch = oViewModel.getProperty("/filenameFilterValue"),
				aFilters = [];

			mParams.filterItems.forEach(function (oItem) {
				var sPath = oItem.getParent().getKey(),
					sOperator = FilterOperator.EQ,
					sValue1 = oItem.getKey(), oFilter, bValue1;
				if (sValue1 === "1") {
					bValue1 = true;
					oFilter = new Filter(sPath, sOperator, bValue1);
				} else if (sValue1 === "2") {
					bValue1 = false;
					oFilter = new Filter(sPath, sOperator, bValue1);
				} else {
					oFilter = new Filter({
						filters: [new Filter(sPath, FilterOperator.NE, true),
						new Filter(sPath, FilterOperator.NE, false)],
						and: true
					});
				}
				aFilters.push(oFilter);
			});
			if (sFileNameSearch) {
				aFilters.push(new Filter(
					{
						path: 'fileName',
						operator: FilterOperator.Contains,
						value1: sFileNameSearch,
						caseSensitive: false
					}));
				var sPrefix = this.getResourceBundle().getText("batchdetail.filterText"),
					sFileNameText = this.getResourceBundle().getText("batchdetail.filename");
				if (mParams.filterString === "") {
					var sFilterText = sPrefix + " " + sFileNameText + "(" + sFileNameSearch + ")";
					mParams.filterString = sFilterText;
				} else {
					mParams.filterString = mParams.filterString + ", " + sFileNameText + "(" + sFileNameSearch + ")";
				}
			}
			// apply filter settings
			oBinding.filter(aFilters);
			// update filter bar
			this.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			this.byId("vsdFilterLabel").setText(mParams.filterString);
		}
	});
});