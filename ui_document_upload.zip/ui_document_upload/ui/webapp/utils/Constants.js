sap.ui.define([], function () {
    "use strict";

    return {
        DATE_FORMAT_KEY: "dateformat",
        DATE_RANGE_KEY: "dateRangePeriod",
        DETAIL_PAGE_ROUTE: "DetailPageRoute",
        DEFAULT_DATE_FORMAT: "dd/MM/yyyy",
        MAX_FILE_SIZE_KEY: "maxFileSize",
        ALLOWED_MIME_TYPE_KEY: "allowedMimeTypes",
        ALLOWED_FILE_TYPE_KEY: "allowedFileTypes",
        FILE_NAME_LENGTH_KEY: "fileNameMaxLength",
        MAX_RECORD_FOR_COMBOBOX: 500,
        API_UPLOAD_FILE: "api/documents/upload",
        API_DB_CONFIG: "Configurations",
        API_USER_INFO: "api/userinfo/currentUser",
        API_BATCH_STATUS: "api/documents/statues"
         


    };
});