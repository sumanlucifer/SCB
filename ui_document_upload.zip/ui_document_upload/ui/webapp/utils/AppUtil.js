sap.ui.define(["./RestCallUtils", "./Constants",
    "sap/ui/core/Fragment", "sap/ui/model/Sorter"
], function (RestCallUtils, Constants, Fragment, Sorter) {
    "use strict";

    return {

        /**
         * Helper method to get default configuration for Date range filter
         */ 
        getDefaultConfiguration: function (that) {
            var oAppModel = that.getModel("appView"),
                sServiceUrl = that.getModel().sServiceUrl,
                sUrl = sServiceUrl + Constants.API_DB_CONFIG;
            RestCallUtils._GET(sUrl, that).then(function (oRes) {
                var oData = oRes.value;
                oAppModel.setProperty("/Configurations", oData);

                var sDateFormat,iFileNameLength, iMaxDateRange, iMaxFileSize, sAllowedMimeType, sAllowedFileType;
                for (var iConfig = 0; iConfig < oData.length; iConfig++) {
                    switch (oData[iConfig].categoryKey) {
                        case Constants.DATE_FORMAT_KEY:
                            sDateFormat = oData[iConfig].startValue;
                            break;
                        case Constants.DATE_RANGE_KEY:
                            iMaxDateRange = oData[iConfig].startValue;
                            break;
                        case Constants.MAX_FILE_SIZE_KEY:
                            iMaxFileSize = oData[iConfig].startValue;
                            break;
                        case Constants.ALLOWED_MIME_TYPE_KEY:
                            sAllowedMimeType = oData[iConfig].startValue;
                            break;
                        case Constants.FILE_NAME_LENGTH_KEY:
                            iFileNameLength = oData[iConfig].startValue;
                            break;
                        case Constants.ALLOWED_FILE_TYPE_KEY:
                            sAllowedFileType = oData[iConfig].startValue;
                            break;
                    }
                }
                // get the file upload related values
                oAppModel.setProperty("/dateRangeMaxValue", iMaxDateRange);
                oAppModel.setProperty("/fileNameMaxLength", parseFloat(iFileNameLength));
                oAppModel.setProperty("/dateFormat", sDateFormat);
                oAppModel.setProperty("/maxFileSize", iMaxFileSize);
                oAppModel.setProperty("/mimeTypes", sAllowedMimeType.split(","));
                oAppModel.setProperty("/fileTypes", sAllowedFileType.split(","));
                oAppModel.setProperty("/allowedFiles", sAllowedFileType);
                oAppModel.refresh(true);
            }).
                catch(function (oError) {

                });
        },
        /**
         * Helper method to get Current user context from java API
         * This API call will return the role related data of current user
         * As well as associated country and legal entity if user is HR admin
         * Basic Information regarding the user as well
         */
        getUserInfo: function (that) {
            return new Promise(function (resolve, reject) {
                var oAppModel = that.getModel("appView"),
                    oUserModel = that.getModel("userModel");
                var sUrl = Constants.API_USER_INFO;
                oAppModel.setProperty("/busy", true);
                RestCallUtils._GET(sUrl, that).then(function (oRes) {
                    oUserModel.setProperty("/IsHR", oRes.hr);
                    oUserModel.setProperty("/IsEmp", oRes.employee);
                    oUserModel.setProperty("/BankId", oRes.bankId);
                    if (oRes.countries) {
                        oUserModel.setProperty("/Countries", oRes.countries);
                    }
                    if (oRes.legalEntities) {
                        oUserModel.setProperty("/LegalEntities", oRes.legalEntities);
                    }
                    oUserModel.refresh(true);
                    if (!oRes.hr) {
                        that.getRouter().navTo("unAuthorized", false);
                        oAppModel.setProperty("/busy", false);
                        reject("unauthorized");
                    }
                    oAppModel.setProperty("/busy", false);
                    resolve("success");
                }.bind(this)).
                    catch(function (oError) {
                        oAppModel.setProperty("/busy", false);
                        oUserModel.setProperty("/IsHR", false);
                        oUserModel.setProperty("/IsEmp", false);
                        oUserModel.refresh(true);
                        that.getRouter().navTo("unAuthorized");
                        reject(oError);
                    }.bind(this));
            });
        }
    };
});